using HarmonyLib;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SkinSyncMod.Patches
{
    [HarmonyPatch(typeof(ConsoleScript), nameof(ConsoleScript.RegisterAllCommands))]
    internal class ConsoleScript_Patch_RegisterAllCommands
    {
        public static void Postfix()
        {
            var skinNames = SkinSync.Instance.availableSkins;
            var autofill = new Dictionary<int, List<string>>
            {
                { 0, new List<string> { "load", "list", "next", "prev", "default", "rescan" } },
                { 1, new List<string>(skinNames) }
            };

            ConsoleScript.Commands.Add(
                new Command(
                    "skin",
                    "SkinSync - 皮肤切换",
                    delegate (string[] args)
                    {
                        string output = HandleSkinCommand(args);
                        ConsoleScript.instance.LogToConsole(output);
                    },
                    autofill,
                    new (string, string)[]
                    {
                        ("action", "load / list / next / prev / default / rescan"),
                        ("name", "皮肤文件夹名称 (用于 load)")
                    }
                )
            );
        }

        internal static string HandleSkinCommand(string[] args)
        {
            var inst = SkinSync.Instance;
            if (inst == null)
                return "[SkinSync] 模组未初始化。";

            if (args.Length == 1)
            {
                string current = inst.currentSkinID ?? "默认";
                return
                    "[SkinSync] 用法:\n" +
                    "  skin load <名称>  - 加载指定皮肤\n" +
                    "  skin list         - 列出所有可用皮肤\n" +
                    "  skin next         - 切换到下一个皮肤\n" +
                    "  skin prev         - 切换到上一个皮肤\n" +
                    "  skin default      - 还原默认皮肤\n" +
                    "  skin rescan       - 重新扫描皮肤文件夹\n" +
                    $"\n当前皮肤: {current}";
            }

            string action = args[1].ToLower();

            if (action == "load")
            {
                if (args.Length < 3)
                    return "[SkinSync] 用法: skin load <皮肤名称>";
                string skinName = args[2];
                if (!inst.availableSkins.Contains(skinName))
                {
                    inst.ScanAvailableSkins();
                    if (!inst.availableSkins.Contains(skinName))
                        return $"[SkinSync] 皮肤 '{skinName}' 未找到。输入 skin list 查看可用皮肤。";
                }
                inst.SwitchToSkin(skinName);
                return $"[SkinSync] 已加载皮肤: {skinName}";
            }

            if (action == "list")
            {
                if (inst.availableSkins.Count == 0)
                    return "[SkinSync] CustomSprites 文件夹中未找到皮肤。";

                string current = inst.currentSkinID ?? "";
                var lines = inst.availableSkins.Select((name, i) =>
                {
                    string marker = name == current ? " ◀" : "";
                    return $"  [{i}] {name}{marker}";
                });
                return $"[SkinSync] 可用皮肤 ({inst.availableSkins.Count}):\n{string.Join("\n", lines)}";
            }

            if (action == "next")
            {
                if (inst.availableSkins.Count == 0)
                    return "[SkinSync] 没有可用的皮肤。";
                inst.currentSkinIndex = (inst.currentSkinIndex + 1) % inst.availableSkins.Count;
                inst.SwitchToSkin(inst.availableSkins[inst.currentSkinIndex]);
                return $"[SkinSync] 已切换到: {inst.currentSkinID}";
            }

            if (action == "prev")
            {
                if (inst.availableSkins.Count == 0)
                    return "[SkinSync] 没有可用的皮肤。";
                inst.currentSkinIndex = (inst.currentSkinIndex - 1 + inst.availableSkins.Count) % inst.availableSkins.Count;
                inst.SwitchToSkin(inst.availableSkins[inst.currentSkinIndex]);
                return $"[SkinSync] 已切换到: {inst.currentSkinID}";
            }

            if (action == "default")
            {
                if (inst.currentSkinID == null)
                    return "[SkinSync] 当前已是默认皮肤。";
                inst.ResetToDefault();
                return "[SkinSync] 已还原默认皮肤。";
            }

            if (action == "rescan")
            {
                inst.ScanAvailableSkins();
                return $"[SkinSync] 重新扫描完成，找到 {inst.availableSkins.Count} 个皮肤。";
            }

            return $"[SkinSync] 未知操作 '{action}'。输入 skin 查看用法。";
        }
    }

    [HarmonyPatch(typeof(ConsoleScript), nameof(ConsoleScript.TryExecuteCommand))]
    [HarmonyPriority(300)]
    internal class ConsoleScript_Patch_TryExecuteCommand
    {
        public static bool Prefix(ConsoleScript __instance, string[] args, bool addToLog)
        {
            if (args.Length > 0 && args[0] == "skin")
            {
                string output = ConsoleScript_Patch_RegisterAllCommands.HandleSkinCommand(args);
                __instance.LogToConsole(output);
                __instance.AddCommandToLogAndClearInput();
                return false;
            }
            return true;
        }
    }
}
