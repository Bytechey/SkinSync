using System;
using HarmonyLib;
using KrokoshaCasualtiesMP;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SkinSyncMod.Patches
{
    [HarmonyPatch(typeof(Net), nameof(Net.ShutdownReset))]
    internal class Net_Patch_ShutdownReset
    {
        public static void Postfix()
        {
            Debug.Log("[SkinSync] Net.ShutdownReset fired, clearing network data");
            SkinNetwork.OnNetworkShutdown();
            if (SkinSync.Instance != null)
            {
                SkinSync.Instance.localNetBody = null;
            }
        }
    }

    [HarmonyPatch(typeof(KrokoshaScavMultiplayer), nameof(KrokoshaScavMultiplayer.OnSceneLoaded))]
    internal class KrokMP_Patch_OnSceneLoaded
    {
        public static void Postfix(Scene a, LoadSceneMode b)
        {
            if (a.name != "SampleScene") return;

            Debug.Log("[SkinSync] KrokoshaScavMultiplayer.OnSceneLoaded fired");

            SkinNetwork.RegisterRecievers();

            if (NetPlayer.ClientIdToPlayerDict != null)
            {
                foreach (var kvp in NetPlayer.ClientIdToPlayerDict)
                {
                    var player = kvp.Value;
                    if (player == null || player.body == null) continue;

                    NetBody pb = null;
                    try { pb = player.playerbody; } catch (Exception) { continue; }
                    if (pb == null) continue;

                    if (SkinNetwork.IsPlayerRegistered(kvp.Key)) continue;

                    SkinNetwork.RegisterPlayer(kvp.Key, pb);

                    if (player == NetPlayer.LOCAL_PLAYER)
                    {
                        SkinSync.Instance.localNetBody = pb;
                        Debug.Log($"[SkinSync] KrokMP OnSceneLoaded: found local player clientId={kvp.Key}");
                    }
                }
            }

            if (SkinSync.Instance.currentSkinID != null && SkinSync.Instance.localNetBody != null)
            {
                SkinSync.Instance.SwitchToSkin(SkinSync.Instance.currentSkinID);
            }

            SkinNetwork.RequestSkinSync();
        }
    }

    [HarmonyPatch(typeof(NetBody), nameof(NetBody.OnFoundNetPlayerInitFinish))]
    internal class NetBody_Patch_OnFoundNetPlayerInitFinish
    {
        public static void Postfix(NetBody __instance)
        {
            if (__instance.player == null || __instance.body == null)
                return;

            SkinNetwork.RegisterRecievers();

            if (SkinNetwork.IsPlayerRegistered(__instance.player.clientId))
                return;

            SkinNetwork.RegisterPlayer(__instance.player.clientId, __instance);

            if (__instance.is_local)
            {
                SkinSync.Instance.localNetBody = __instance;
                Debug.Log($"[SkinSync] Local NetBody found: netId={__instance.netId}, clientId={__instance.player.clientId}");

                if (SkinSync.Instance.currentSkinID != null)
                {
                    SkinSync.Instance.SwitchToSkin(SkinSync.Instance.currentSkinID);
                }
            }

            if (KrokoshaScavMultiplayer.network_system_is_running && __instance.player != null)
            {
                SkinNetwork.TryApplyPendingSkin(__instance.player.clientId, __instance.chara);
                SkinNetwork.RequestSkinSync();
            }
        }
    }

    [HarmonyPatch(typeof(NetBody), nameof(NetBody.OnDestroy))]
    internal class NetBody_Patch_OnDestroy
    {
        public static void Prefix(NetBody __instance)
        {
            if (__instance.is_local && SkinSync.Instance.localNetBody == __instance)
            {
                SkinSync.Instance.localNetBody = null;
            }

            if (__instance.player != null)
            {
                SkinNetwork.UnregisterPlayer(__instance.player.clientId);
            }
        }
    }
}
