using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using UnityEngine;

namespace SkinSyncMod
{
    public static class SkinApplier
    {
        private static Dictionary<string, SkinData> _skinCache = new Dictionary<string, SkinData>();

        private static Dictionary<string, Sprite> _ogSprites;

        internal static readonly string[] bodyfilenames =
        {
            "Body/experimentTail.png",
            "Body/experimentFoot.png",
            "Body/experimentUpTorso.png",
            "Body/experimentUpArm.png",
            "Body/experimentThigh.png",
            "Body/experimentDownTorso.png",
            "Body/experimentDownArm.png",
            "Body/experimentCrus.png",
            "Body/experimentEyeGoneHealed.png",
            "Body/experimentEyeGone.png",
            "Body/experimentEyeClosed.png",
            "Body/experimentEyeScaredBack.png",
            "Body/experimentEyeScared.png",
            "Body/experimentEyeSadBack.png",
            "Body/experimentEyeSad.png",
            "Body/experimentHead.png",
            "Body/experimentEyePanic.png",
            "Body/experimentEyeOpen.png",
            "Body/experimentEyeLookBack.png",
            "Body/experimentEyeHalfClosedBack.png",
            "Body/experimentEyeHalfClosed.png",
            "Body/experimentHeadDisfigured3Healed.png",
            "Body/experimentHeadDisfigured3.png",
            "Body/experimentHeadDisfigured2Healed.png",
            "Body/experimentHeadDisfigured2.png",
            "Body/experimentHeadDisfigured1Healed.png",
            "Body/experimentHeadDisfigured1.png",
            "Body/experimentHeadBackMouth.png",
            "Body/experimentHeadBackMouthMini.png",
            "Body/experimentHeadBack.png",
            "Body/experimentHandB.png",
            "Body/experimentHandF.png",
            "Body/experimentNosebleed.png",
            "Body/experimentEyeHappy.png",
        };

        internal class SkinData
        {
            internal Dictionary<string, Sprite> sprites = new Dictionary<string, Sprite>();
            internal Dictionary<string, Sprite> spritesR = new Dictionary<string, Sprite>();
            internal bool hasRSprites;
        }

        internal static Dictionary<string, Sprite> OgSprites => _ogSprites;

        private static Dictionary<int, ActiveSkin> _activeSkins = new Dictionary<int, ActiveSkin>();

        internal class ActiveSkin
        {
            internal string skinID;
            internal SkinData data;
            internal Body body;
            internal GameObject playerObj;
            internal bool lastFlipX;
            internal bool cacheDirty = true;
            internal SpriteRenderer[] cachedRenderers;
        }

        internal static void LoadOgSprites()
        {
            if (_ogSprites != null) return;
            _ogSprites = new Dictionary<string, Sprite>();

            var assembly = Assembly.GetExecutingAssembly();
            string resourcePrefix = "SkinSyncMod.resources.og.Body.";

            foreach (var name in assembly.GetManifestResourceNames())
            {
                if (!name.StartsWith(resourcePrefix)) continue;
                if (!name.EndsWith(".png")) continue;

                string spriteName = name.Substring(resourcePrefix.Length);
                spriteName = Path.GetFileNameWithoutExtension(spriteName);

                using (var stream = assembly.GetManifestResourceStream(name))
                {
                    if (stream == null) continue;
                    byte[] data = new byte[stream.Length];
                    stream.Read(data, 0, data.Length);

                    Texture2D tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                    tex.filterMode = FilterMode.Point;
                    if (ImageConversion.LoadImage(tex, data))
                    {
                        Sprite sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 8f);
                        sprite.name = spriteName;
                        _ogSprites[spriteName] = sprite;
                    }
                }
            }

            Debug.Log($"[SkinSync] Loaded {_ogSprites.Count} OG sprites from embedded resources.");
        }

        public static void ApplySkinToPlayer(GameObject playerObj, string characterName)
        {
            if (playerObj == null) return;

            if (!_skinCache.TryGetValue(characterName, out var skinData))
            {
                skinData = LoadCharacterSkin(characterName);
                if (skinData == null || skinData.sprites.Count == 0)
                {
                    Debug.LogWarning($"[SkinSync] No sprites found for character {characterName}");
                    return;
                }
                _skinCache[characterName] = skinData;
            }

            int instanceId = playerObj.GetInstanceID();

            if (_activeSkins.TryGetValue(instanceId, out var oldActive) && oldActive.skinID != null)
            {
                RestoreFromOg(playerObj);
            }

            var active = new ActiveSkin
            {
                skinID = characterName,
                data = skinData,
                body = playerObj.GetComponentInChildren<Body>(),
                playerObj = playerObj,
                lastFlipX = false,
                cacheDirty = true,
            };
            _activeSkins[instanceId] = active;

            Debug.Log($"[SkinSync] ApplySkinToPlayer: skinID={characterName}, body={(active.body != null ? "found" : "NULL")}, hasRSprites={skinData.hasRSprites}");

            ReplaceAllSprites(playerObj, skinData, false);
        }

        public static void UpdateAllActiveSkins()
        {
            List<int> toRemove = null;
            foreach (var kvp in _activeSkins)
            {
                var active = kvp.Value;
                if (active.playerObj == null)
                {
                    if (toRemove == null) toRemove = new List<int>();
                    toRemove.Add(kvp.Key);
                    continue;
                }

                ReplaceSpritesDirect(active);
            }
            if (toRemove != null)
            {
                foreach (int id in toRemove)
                    _activeSkins.Remove(id);
            }
        }

        private static void ReplaceSpritesDirect(ActiveSkin active)
        {
            if (active.body == null)
            {
                active.body = active.playerObj.GetComponentInChildren<Body>();
                if (active.body == null) return;
            }

            bool flipped = active.body.transform.localScale.x < 0;
            SkinData skinData = active.data;

            if (active.cacheDirty || active.cachedRenderers == null)
            {
                active.cachedRenderers = active.playerObj.GetComponentsInChildren<SpriteRenderer>(true);
                active.cacheDirty = false;
            }

            bool anyNull = false;
            foreach (var sr in active.cachedRenderers)
            {
                if (sr == null) { anyNull = true; continue; }
                if (sr.sprite == null) continue;

                string baseName = GetBaseName(sr.sprite.name);

                if (flipped && skinData.hasRSprites && skinData.spritesR.TryGetValue(baseName, out var rSprite))
                {
                    if (sr.sprite != rSprite)
                        sr.sprite = rSprite;
                }
                else if (skinData.sprites.TryGetValue(baseName, out var aSprite))
                {
                    if (sr.sprite != aSprite)
                        sr.sprite = aSprite;
                }
            }

            if (anyNull)
            {
                active.cachedRenderers = active.playerObj.GetComponentsInChildren<SpriteRenderer>(true);
            }
        }

        private static void ReplaceAllSprites(GameObject playerObj, SkinData skinData, bool flipped)
        {
            foreach (var sr in playerObj.GetComponentsInChildren<SpriteRenderer>(true))
            {
                if (sr?.sprite == null) continue;
                string baseName = GetBaseName(sr.sprite.name);

                if (flipped && skinData.hasRSprites && skinData.spritesR.TryGetValue(baseName, out var rSprite))
                {
                    if (sr.sprite != rSprite)
                        sr.sprite = rSprite;
                }
                else if (skinData.sprites.TryGetValue(baseName, out var aSprite))
                {
                    if (sr.sprite != aSprite)
                        sr.sprite = aSprite;
                }
            }

            foreach (var face in playerObj.GetComponentsInChildren<FacialExpression>(true))
                ReplaceFacialExpressionSprites(face, skinData);
        }

        private static SkinData LoadCharacterSkin(string character)
        {
            var data = new SkinData();
            string basePath = Path.Combine(SkinSync.SkinsRoot, character);

            if (!Directory.Exists(basePath))
            {
                Debug.LogWarning($"[SkinSync] Skin folder not found: {basePath}");
                return data;
            }

            int loadedCount = 0;
            int rCount = 0;

            foreach (string filename in bodyfilenames)
            {
                string fullPath = Path.Combine(basePath, filename);
                string name = Path.GetFileNameWithoutExtension(filename);
                string ext = Path.GetExtension(filename);
                string dir = Path.GetDirectoryName(filename);

                if (File.Exists(fullPath))
                {
                    Sprite sprite = LoadSpriteFromFile(fullPath, name);
                    if (sprite != null)
                    {
                        data.sprites[name] = sprite;
                        loadedCount++;
                    }
                }

                string rFilename = string.IsNullOrEmpty(dir) ? name + "_R" + ext : dir + "/" + name + "_R" + ext;
                string rFullPath = Path.Combine(basePath, rFilename);
                if (File.Exists(rFullPath))
                {
                    Sprite rSprite = LoadSpriteFromFile(rFullPath, name);
                    if (rSprite != null)
                    {
                        data.spritesR[name] = rSprite;
                        rCount++;
                    }
                }
            }

            data.hasRSprites = data.spritesR.Count > 0;
            Debug.Log($"[SkinSync] LoadCharacterSkin: {character}, loaded={loadedCount}, _R={rCount}");
            return data;
        }

        private static Sprite LoadSpriteFromFile(string filePath, string spriteName)
        {
            byte[] data = File.ReadAllBytes(filePath);
            Texture2D tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            if (ImageConversion.LoadImage(tex, data))
            {
                Sprite sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 8f);
                sprite.name = spriteName;
                return sprite;
            }
            return null;
        }

        private static void ReplaceFacialExpressionSprites(FacialExpression face, SkinData skinData)
        {
            skinData.sprites.TryGetValue("experimentHeadBack", out face.defaultHead);
            skinData.sprites.TryGetValue("experimentHeadBackMouth", out face.defaultHeadMouth);
            skinData.sprites.TryGetValue("experimentHeadBackMouthMini", out face.defaultHeadMouthHalf);
            skinData.sprites.TryGetValue("experimentEyeGone", out face.eyesGone);
            skinData.sprites.TryGetValue("experimentEyeGoneHealed", out face.eyesGoneHealed);

            if (face.disfiguredHead != null && face.disfiguredHead.Length >= 3)
            {
                skinData.sprites.TryGetValue("experimentHeadDisfigured1", out face.disfiguredHead[0]);
                skinData.sprites.TryGetValue("experimentHeadDisfigured2", out face.disfiguredHead[1]);
                skinData.sprites.TryGetValue("experimentHeadDisfigured3", out face.disfiguredHead[2]);
            }
            if (face.disfiguredHeadHeal != null && face.disfiguredHeadHeal.Length >= 3)
            {
                skinData.sprites.TryGetValue("experimentHeadDisfigured1Healed", out face.disfiguredHeadHeal[0]);
                skinData.sprites.TryGetValue("experimentHeadDisfigured2Healed", out face.disfiguredHeadHeal[1]);
                skinData.sprites.TryGetValue("experimentHeadDisfigured3Healed", out face.disfiguredHeadHeal[2]);
            }

            for (int i = 0; i < face.eyeList.Count; i++)
            {
                var eye = face.eyeList[i];
                bool changed = false;
                if (eye.front != null)
                {
                    string baseName = GetBaseName(eye.front.name);
                    if (skinData.sprites.TryGetValue(baseName, out var s)) { eye.front = s; changed = true; }
                }
                if (eye.back != null)
                {
                    string baseName = GetBaseName(eye.back.name);
                    if (skinData.sprites.TryGetValue(baseName, out var s)) { eye.back = s; changed = true; }
                }
                if (changed) face.eyeList[i] = eye;
            }
        }

        private static string GetBaseName(string spriteName)
        {
            if (spriteName != null && spriteName.EndsWith("_R"))
                return spriteName.Substring(0, spriteName.Length - 2);
            return spriteName;
        }

        public static void ApplySkinFromMemory(GameObject playerObj, byte[] zipData)
        {
            if (playerObj == null || zipData == null || zipData.Length == 0) return;

            var skinData = LoadSkinFromMemory(zipData);
            if (skinData == null || skinData.sprites.Count == 0)
            {
                Debug.LogWarning("[SkinSync] Failed to load skin from memory");
                return;
            }

            int instanceId = playerObj.GetInstanceID();

            if (_activeSkins.TryGetValue(instanceId, out var oldActive) && oldActive.skinID != null)
            {
                RestoreFromOg(playerObj);
            }

            var active = new ActiveSkin
            {
                skinID = "p2p",
                data = skinData,
                body = playerObj.GetComponentInChildren<Body>(),
                playerObj = playerObj,
                lastFlipX = false,
                cacheDirty = true,
            };
            _activeSkins[instanceId] = active;

            ReplaceAllSprites(playerObj, skinData, false);
        }

        private static SkinData LoadSkinFromMemory(byte[] zipData)
        {
            var data = new SkinData();
            int loadedCount = 0;
            int rCount = 0;

            try
            {
                using (var ms = new MemoryStream(zipData))
                using (var archive = new ZipArchive(ms, ZipArchiveMode.Read))
                {
                    foreach (string filename in bodyfilenames)
                    {
                        string name = Path.GetFileNameWithoutExtension(filename);
                        string ext = Path.GetExtension(filename);
                        string dir = Path.GetDirectoryName(filename);

                        Sprite sprite = LoadSpriteFromArchive(archive, filename);
                        if (sprite != null)
                        {
                            sprite.name = name;
                            data.sprites[name] = sprite;
                            loadedCount++;
                        }

                        string rFilename = string.IsNullOrEmpty(dir) ? name + "_R" + ext : dir + "/" + name + "_R" + ext;
                        Sprite rSprite = LoadSpriteFromArchive(archive, rFilename);
                        if (rSprite != null)
                        {
                            rSprite.name = name;
                            data.spritesR[name] = rSprite;
                            rCount++;
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[SkinSync] LoadSkinFromMemory failed: {ex.Message}");
                return null;
            }

            data.hasRSprites = data.spritesR.Count > 0;
            Debug.Log($"[SkinSync] LoadSkinFromMemory: loaded={loadedCount}, _R={rCount}");
            return data;
        }

        private static Sprite LoadSpriteFromArchive(ZipArchive archive, string filename)
        {
            ZipArchiveEntry entry = archive.GetEntry(filename);
            if (entry == null)
            {
                foreach (ZipArchiveEntry e in archive.Entries)
                {
                    if (e.FullName.EndsWith("/" + filename, StringComparison.OrdinalIgnoreCase))
                    {
                        entry = e;
                        break;
                    }
                }
            }
            if (entry == null) return null;

            byte[] entryBytes;
            using (var entryStream = entry.Open())
            {
                entryBytes = new byte[entry.Length];
                int bytesRead = 0;
                while (bytesRead < entryBytes.Length)
                {
                    int read = entryStream.Read(entryBytes, bytesRead, entryBytes.Length - bytesRead);
                    if (read == 0) break;
                    bytesRead += read;
                }
            }

            Texture2D tex = new Texture2D(2, 2);
            tex.filterMode = FilterMode.Point;
            if (ImageConversion.LoadImage(tex, entryBytes))
            {
                Sprite sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 8, 0, SpriteMeshType.Tight);
                sprite.name = Path.GetFileNameWithoutExtension(filename);
                return sprite;
            }
            return null;
        }

        public static void ClearCache()
        {
            _skinCache.Clear();
        }

        public static void RemoveActiveSkin(int instanceId)
        {
            _activeSkins.Remove(instanceId);
        }

        public static void ResetToDefault(GameObject playerObj)
        {
            if (playerObj == null) return;
            int instanceId = playerObj.GetInstanceID();

            RestoreFromOg(playerObj);
            _activeSkins.Remove(instanceId);
        }

        private static void RestoreFromOg(GameObject playerObj)
        {
            if (_ogSprites == null || _ogSprites.Count == 0)
            {
                LoadOgSprites();
                if (_ogSprites.Count == 0)
                {
                    Debug.LogWarning("[SkinSync] No OG sprites loaded, cannot restore.");
                    return;
                }
            }

            foreach (var sr in playerObj.GetComponentsInChildren<SpriteRenderer>(true))
            {
                if (sr?.sprite == null) continue;
                string baseName = GetBaseName(sr.sprite.name);
                if (_ogSprites.TryGetValue(baseName, out var ogSprite))
                    sr.sprite = ogSprite;
            }

            foreach (var face in playerObj.GetComponentsInChildren<FacialExpression>(true))
            {
                RestoreFaceFromOg(face);
            }
        }

        private static void RestoreFaceFromOg(FacialExpression face)
        {
            if (face.defaultHead != null)
            {
                string name = GetBaseName(face.defaultHead.name);
                if (_ogSprites.TryGetValue(name, out var og)) face.defaultHead = og;
            }
            if (face.defaultHeadMouth != null)
            {
                string name = GetBaseName(face.defaultHeadMouth.name);
                if (_ogSprites.TryGetValue(name, out var og)) face.defaultHeadMouth = og;
            }
            if (face.defaultHeadMouthHalf != null)
            {
                string name = GetBaseName(face.defaultHeadMouthHalf.name);
                if (_ogSprites.TryGetValue(name, out var og)) face.defaultHeadMouthHalf = og;
            }
            if (face.eyesGone != null)
            {
                string name = GetBaseName(face.eyesGone.name);
                if (_ogSprites.TryGetValue(name, out var og)) face.eyesGone = og;
            }
            if (face.eyesGoneHealed != null)
            {
                string name = GetBaseName(face.eyesGoneHealed.name);
                if (_ogSprites.TryGetValue(name, out var og)) face.eyesGoneHealed = og;
            }

            if (face.disfiguredHead != null)
            {
                for (int i = 0; i < face.disfiguredHead.Length; i++)
                {
                    if (face.disfiguredHead[i] != null)
                    {
                        string name = GetBaseName(face.disfiguredHead[i].name);
                        if (_ogSprites.TryGetValue(name, out var og)) face.disfiguredHead[i] = og;
                    }
                }
            }
            if (face.disfiguredHeadHeal != null)
            {
                for (int i = 0; i < face.disfiguredHeadHeal.Length; i++)
                {
                    if (face.disfiguredHeadHeal[i] != null)
                    {
                        string name = GetBaseName(face.disfiguredHeadHeal[i].name);
                        if (_ogSprites.TryGetValue(name, out var og)) face.disfiguredHeadHeal[i] = og;
                    }
                }
            }
            if (face.eyeList != null)
            {
                for (int i = 0; i < face.eyeList.Count; i++)
                {
                    var eye = face.eyeList[i];
                    bool changed = false;
                    if (eye.front != null)
                    {
                        string name = GetBaseName(eye.front.name);
                        if (_ogSprites.TryGetValue(name, out var og)) { eye.front = og; changed = true; }
                    }
                    if (eye.back != null)
                    {
                        string name = GetBaseName(eye.back.name);
                        if (_ogSprites.TryGetValue(name, out var og)) { eye.back = og; changed = true; }
                    }
                    if (changed) face.eyeList[i] = eye;
                }
            }
        }
    }
}
