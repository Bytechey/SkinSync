using KrokoshaCasualtiesMP;
using LiteNetLib;
using LiteNetLib.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using UnityEngine;

namespace SkinSyncMod
{
    public static class SkinNetwork
    {
        const ushort MSG_SKIN_CHANGE = 50000;
        const ushort MSG_SKIN_DATA_START = 50001;
        const ushort MSG_SKIN_DATA_CHUNK = 50002;
        const ushort MSG_SKIN_STATE_RELAY = 50003;
        const ushort MSG_SKIN_SYNC_REQUEST = 50004;
        const ushort MSG_SKIN_RESEND_REQUEST = 50005;

        const int CHUNK_SIZE = 32768;
        const int MAX_SKIN_SIZE = 20 * 1024 * 1024;
        const float TRANSFER_TIMEOUT = 30f;
        const float COMPLETED_SKIN_TTL = 60f;
        const float CLEANUP_INTERVAL = 5f;

        static Dictionary<string, PendingTransfer> pendingTransfers = new Dictionary<string, PendingTransfer>();
        static Dictionary<uint, CompletedSkin> completedSkins = new Dictionary<uint, CompletedSkin>();
        static Dictionary<uint, string> activeLocalSkins = new Dictionary<uint, string>();
        static Dictionary<uint, bool> activeSkinStates = new Dictionary<uint, bool>();
        static Dictionary<uint, NetBody> playerBodies = new Dictionary<uint, NetBody>();
        static float lastCleanupTime;
        static bool receiversRegistered = false;

        class PendingTransfer
        {
            internal string skinName;
            internal byte[] data;
            internal int receivedChunks;
            internal int totalChunks;
            internal float startTime;
        }

        class CompletedSkin
        {
            internal string skinName;
            internal byte[] data;
            internal float completeTime;
        }

        static void LogInfo(string msg) => Debug.Log($"[SkinSync] {msg}");
        static void LogWarning(string msg) => Debug.LogWarning($"[SkinSync] {msg}");

        static IReadOnlyList<uint> GetClientIdsExcept(uint excludeId)
        {
            var all = ServerMain.AllClientIds;
            if (all == null || all.Count == 0) return all;
            var result = new List<uint>(all.Count);
            foreach (uint id in all)
            {
                if (id != excludeId) result.Add(id);
            }
            return result;
        }

        public static void RegisterRecievers()
        {
            if (receiversRegistered) return;
            if (!KrokoshaScavMultiplayer.network_system_is_running) return;

            try
            {
                Net.RegisterServerReciever(MSG_SKIN_CHANGE, ServerReciever_SkinChange);
                Net.RegisterServerReciever(MSG_SKIN_DATA_START, ServerReciever_SkinDataStart);
                Net.RegisterServerReciever(MSG_SKIN_DATA_CHUNK, ServerReciever_SkinDataChunk);
                Net.RegisterServerReciever(MSG_SKIN_SYNC_REQUEST, ServerReciever_SkinSyncRequest);

                Net.RegisterClientReciever(MSG_SKIN_CHANGE, ClientReciever_SkinChange);
                Net.RegisterClientReciever(MSG_SKIN_DATA_START, ClientReciever_SkinDataStart);
                Net.RegisterClientReciever(MSG_SKIN_DATA_CHUNK, ClientReciever_SkinDataChunk);
                Net.RegisterClientReciever(MSG_SKIN_STATE_RELAY, ClientReciever_SkinStateRelay);
                Net.RegisterClientReciever(MSG_SKIN_RESEND_REQUEST, ClientReciever_SkinResendRequest);

                receiversRegistered = true;
                LogInfo("Network receivers registered");
            }
            catch (Exception ex)
            {
                LogWarning($"RegisterRecievers failed (handlers may already exist): {ex.Message}");
                receiversRegistered = true;
            }
        }

        public static void SendSkinChange(string skinID, uint netId)
        {
            if (!KrokoshaScavMultiplayer.network_system_is_running) return;
            NetDataWriter writer = Net.CreateWriter(MSG_SKIN_CHANGE, 256, true);
            writer.Put(skinID ?? "");
            writer.Put(netId);
            Net.Client_Send(DeliveryMethod.ReliableOrdered, writer);
        }

        public static void SendLocalSkinData(string skinID)
        {
            if (!KrokoshaScavMultiplayer.network_system_is_running) return;

            string skinPath = Path.Combine(SkinSync.SkinsRoot, skinID);
            if (!Directory.Exists(skinPath))
            {
                LogWarning($"SendLocalSkinData: skin folder not found: {skinPath}");
                return;
            }

            byte[] zipData = PackSkinToMemory(skinPath);
            if (zipData == null || zipData.Length == 0)
            {
                LogWarning($"SendLocalSkinData: failed to pack skin: {skinID}");
                return;
            }
            if (zipData.Length > MAX_SKIN_SIZE)
            {
                LogWarning($"SendLocalSkinData: skin too large: {zipData.Length} bytes");
                return;
            }

            int totalChunks = (zipData.Length + CHUNK_SIZE - 1) / CHUNK_SIZE;

            NetDataWriter startWriter = Net.CreateWriter(MSG_SKIN_DATA_START, 256, true);
            startWriter.Put(skinID);
            startWriter.Put(totalChunks);
            startWriter.Put(zipData.Length);
            Net.Client_Send(DeliveryMethod.ReliableOrdered, startWriter);

            for (int i = 0; i < totalChunks; i++)
            {
                int offset = i * CHUNK_SIZE;
                int size = Math.Min(CHUNK_SIZE, zipData.Length - offset);
                byte[] chunk = new byte[size];
                Array.Copy(zipData, offset, chunk, 0, size);

                NetDataWriter chunkWriter = Net.CreateWriter(MSG_SKIN_DATA_CHUNK, CHUNK_SIZE + 256, true);
                chunkWriter.Put(skinID);
                chunkWriter.Put(i);
                chunkWriter.PutBytesWithLength(chunk);
                Net.Client_Send(DeliveryMethod.ReliableOrdered, chunkWriter);
            }

            LogInfo($"P2P skin transfer started: {skinID}, {zipData.Length} bytes, {totalChunks} chunks");
        }

        static byte[] PackSkinToMemory(string skinPath)
        {
            try
            {
                using (var ms = new MemoryStream())
                {
                    using (var archive = new ZipArchive(ms, ZipArchiveMode.Create, true))
                    {
                        AddDirectoryToArchive(archive, skinPath, "");
                    }
                    return ms.ToArray();
                }
            }
            catch (Exception ex)
            {
                LogWarning($"PackSkinToMemory failed: {ex.Message}");
                return null;
            }
        }

        static void AddDirectoryToArchive(ZipArchive archive, string sourceDir, string entryPrefix)
        {
            foreach (var file in Directory.GetFiles(sourceDir))
            {
                string entryName = string.IsNullOrEmpty(entryPrefix)
                    ? Path.GetFileName(file)
                    : entryPrefix + "/" + Path.GetFileName(file);
                var entry = archive.CreateEntry(entryName, System.IO.Compression.CompressionLevel.Fastest);
                using (var entryStream = entry.Open())
                using (var fileStream = File.OpenRead(file))
                {
                    fileStream.CopyTo(entryStream);
                }
            }
            foreach (var dir in Directory.GetDirectories(sourceDir))
            {
                string dirName = Path.GetFileName(dir);
                string prefix = string.IsNullOrEmpty(entryPrefix) ? dirName : entryPrefix + "/" + dirName;
                AddDirectoryToArchive(archive, dir, prefix);
            }
        }

        public static void RequestSkinSync()
        {
            if (!KrokoshaScavMultiplayer.network_system_is_running) return;
            if (!Net.is_client && !Net.is_server) return;
            NetDataWriter writer = Net.CreateWriter(MSG_SKIN_SYNC_REQUEST, 8, true);
            Net.Client_Send(DeliveryMethod.ReliableOrdered, writer);
        }

        public static void TryApplyPendingSkin(uint clientId, GameObject playerObj)
        {
            if (playerObj == null)
            {
                if (playerBodies.TryGetValue(clientId, out var nb) && nb.chara != null)
                    playerObj = nb.chara;
                else
                    return;
            }

            if (completedSkins.TryGetValue(clientId, out var completed))
            {
                LogInfo($"Applying cached P2P skin '{completed.skinName}' for client {clientId}");
                SkinApplier.ApplySkinFromMemory(playerObj, completed.data);
                completedSkins.Remove(clientId);
            }
        }

        public static void RegisterPlayer(uint clientId, NetBody netBody)
        {
            playerBodies[clientId] = netBody;
            LogInfo($"Registered player clientId={clientId}, netId={netBody.netId}");
        }

        public static bool IsPlayerRegistered(uint clientId)
        {
            return playerBodies.ContainsKey(clientId);
        }

        public static void UnregisterPlayer(uint clientId)
        {
            playerBodies.Remove(clientId);
            activeLocalSkins.Remove(clientId);
            activeSkinStates.Remove(clientId);
            completedSkins.Remove(clientId);
        }

        public static void ClearAllData()
        {
            playerBodies.Clear();
            pendingTransfers.Clear();
            completedSkins.Clear();
        }

        public static void OnNetworkShutdown()
        {
            playerBodies.Clear();
            activeLocalSkins.Clear();
            activeSkinStates.Clear();
            pendingTransfers.Clear();
            completedSkins.Clear();
            receiversRegistered = false;
        }

        public static void CleanupTimedOutTransfers()
        {
            if (Time.unscaledTime - lastCleanupTime < CLEANUP_INTERVAL) return;
            lastCleanupTime = Time.unscaledTime;

            List<string> expired = null;
            foreach (var kvp in pendingTransfers)
            {
                if (Time.unscaledTime - kvp.Value.startTime > TRANSFER_TIMEOUT)
                {
                    if (expired == null) expired = new List<string>();
                    expired.Add(kvp.Key);
                }
            }
            if (expired != null)
            {
                foreach (string key in expired)
                    pendingTransfers.Remove(key);
            }

            List<uint> expiredCompleted = null;
            List<KeyValuePair<uint, CompletedSkin>> toApply = null;
            foreach (var kvp in completedSkins)
            {
                if (Time.unscaledTime - kvp.Value.completeTime > COMPLETED_SKIN_TTL)
                {
                    if (expiredCompleted == null) expiredCompleted = new List<uint>();
                    expiredCompleted.Add(kvp.Key);
                }
                else
                {
                    GameObject playerObj = FindPlayerByClientId(kvp.Key);
                    if (playerObj != null)
                    {
                        if (toApply == null) toApply = new List<KeyValuePair<uint, CompletedSkin>>();
                        toApply.Add(kvp);
                    }
                }
            }
            if (expiredCompleted != null)
            {
                foreach (uint id in expiredCompleted)
                    completedSkins.Remove(id);
            }
            if (toApply != null)
            {
                foreach (var kvp in toApply)
                {
                    LogInfo($"Cleanup: applying cached skin '{kvp.Value.skinName}' for client {kvp.Key}");
                    SkinApplier.ApplySkinFromMemory(FindPlayerByClientId(kvp.Key), kvp.Value.data);
                    completedSkins.Remove(kvp.Key);
                }
            }
        }

        static void ServerReciever_SkinChange(uint clientId, ref NetDataReader reader)
        {
            string skinID = reader.GetString();
            uint netId = reader.GetUInt();

            activeLocalSkins[clientId] = skinID;

            NetDataWriter writer = Net.CreateWriter(MSG_SKIN_CHANGE, 256, true);
            writer.Put(clientId);
            writer.Put(skinID);
            writer.Put(netId);
            Net.Server_SendToClients(DeliveryMethod.ReliableOrdered, writer, GetClientIdsExcept(clientId));
        }

        static void ServerReciever_SkinDataStart(uint clientId, ref NetDataReader reader)
        {
            string skinName = reader.GetString();
            int totalChunks = reader.GetInt();
            int totalSize = reader.GetInt();

            activeLocalSkins[clientId] = skinName;

            NetDataWriter writer = Net.CreateWriter(MSG_SKIN_DATA_START, 256, true);
            writer.Put(clientId);
            writer.Put(skinName);
            writer.Put(totalChunks);
            writer.Put(totalSize);
            Net.Server_SendToClients(DeliveryMethod.ReliableOrdered, writer, GetClientIdsExcept(clientId));
        }

        static void ServerReciever_SkinDataChunk(uint clientId, ref NetDataReader reader)
        {
            string skinName = reader.GetString();
            int chunkIndex = reader.GetInt();
            byte[] chunkData = reader.GetBytesWithLength();

            NetDataWriter writer = Net.CreateWriter(MSG_SKIN_DATA_CHUNK, CHUNK_SIZE + 256, true);
            writer.Put(clientId);
            writer.Put(skinName);
            writer.Put(chunkIndex);
            writer.PutBytesWithLength(chunkData);
            Net.Server_SendToClients(DeliveryMethod.ReliableOrdered, writer, GetClientIdsExcept(clientId));
        }

        static void ServerReciever_SkinSyncRequest(uint clientId, ref NetDataReader reader)
        {
            LogInfo($"SkinSyncRequest from client {clientId}");

            foreach (var kvp in activeLocalSkins)
            {
                uint senderId = kvp.Key;
                string skinName = kvp.Value;

                if (senderId == clientId) continue;
                if (string.IsNullOrEmpty(skinName)) continue;

                if (senderId == 0U)
                {
                    string skinPath = Path.Combine(SkinSync.SkinsRoot, skinName);
                    if (Directory.Exists(skinPath))
                    {
                        byte[] zipData = PackSkinToMemory(skinPath);
                        if (zipData != null && zipData.Length <= MAX_SKIN_SIZE)
                        {
                            int totalChunks = (zipData.Length + CHUNK_SIZE - 1) / CHUNK_SIZE;

                            NetDataWriter startWriter = Net.CreateWriter(MSG_SKIN_DATA_START, 256, true);
                            startWriter.Put(senderId);
                            startWriter.Put(skinName);
                            startWriter.Put(totalChunks);
                            startWriter.Put(zipData.Length);
                            Net.Server_SendToClients(DeliveryMethod.ReliableOrdered, startWriter, clientId);

                            for (int i = 0; i < totalChunks; i++)
                            {
                                int offset = i * CHUNK_SIZE;
                                int size = Math.Min(CHUNK_SIZE, zipData.Length - offset);
                                byte[] chunk = new byte[size];
                                Array.Copy(zipData, offset, chunk, 0, size);

                                NetDataWriter chunkWriter = Net.CreateWriter(MSG_SKIN_DATA_CHUNK, CHUNK_SIZE + 256, true);
                                chunkWriter.Put(senderId);
                                chunkWriter.Put(skinName);
                                chunkWriter.Put(i);
                                chunkWriter.PutBytesWithLength(chunk);
                                Net.Server_SendToClients(DeliveryMethod.ReliableOrdered, chunkWriter, clientId);
                            }

                            LogInfo($"SkinSync: sent host skin {skinName} to client {clientId}");
                        }
                    }
                }
                else
                {
                    NetDataWriter resendWriter = Net.CreateWriter(MSG_SKIN_RESEND_REQUEST, 16, true);
                    resendWriter.Put(clientId);
                    Net.Server_SendToClients(DeliveryMethod.ReliableOrdered, resendWriter, senderId);
                    LogInfo($"SkinSync: sent resend request to client {senderId} for new client {clientId}");
                }
            }

            foreach (var kvp in activeSkinStates)
            {
                uint senderId = kvp.Key;
                bool state = kvp.Value;
                if (senderId == clientId) continue;

                NetDataWriter writer = Net.CreateWriter(MSG_SKIN_STATE_RELAY, 8, true);
                writer.Put(senderId);
                writer.Put(state);
                Net.Server_SendToClients(DeliveryMethod.ReliableOrdered, writer, clientId);
            }
        }

        static void ClientReciever_SkinChange(uint clientId, ref NetDataReader reader)
        {
            uint senderClientId = reader.GetUInt();
            string skinID = reader.GetString();
            uint netId = reader.GetUInt();

            if (IsLocalPlayer(senderClientId)) return;

            if (string.IsNullOrEmpty(skinID))
            {
                completedSkins.Remove(senderClientId);
                GameObject playerObj = FindPlayerByClientId(senderClientId);
                if (playerObj == null) playerObj = FindPlayerByNetId(netId);
                if (playerObj != null)
                {
                    SkinApplier.ResetToDefault(playerObj);
                    LogInfo($"Received skin reset from client {senderClientId}");
                }
            }
        }

        static GameObject FindPlayerByNetId(uint netId)
        {
            foreach (var kvp in playerBodies)
            {
                if (kvp.Value.netId == netId && kvp.Value.chara != null)
                    return kvp.Value.chara;
            }

            if (NetBody.all_instances != null)
            {
                foreach (var nb in NetBody.all_instances)
                {
                    if (nb.netId == netId && nb.chara != null)
                        return nb.chara;
                }
            }
            return null;
        }

        static void ClientReciever_SkinDataStart(uint clientId, ref NetDataReader reader)
        {
            uint senderClientId = reader.GetUInt();
            string skinName = reader.GetString();
            int totalChunks = reader.GetInt();
            int totalSize = reader.GetInt();

            if (IsLocalPlayer(senderClientId)) return;

            if (totalSize > MAX_SKIN_SIZE)
            {
                LogWarning($"Incoming skin data too large: {totalSize} bytes, discarding");
                return;
            }

            string key = $"{senderClientId}_{skinName}";
            pendingTransfers[key] = new PendingTransfer
            {
                skinName = skinName,
                data = new byte[totalSize],
                receivedChunks = 0,
                totalChunks = totalChunks,
                startTime = Time.unscaledTime,
            };

            LogInfo($"P2P skin transfer started: {skinName} from {senderClientId}, {totalChunks} chunks, {totalSize} bytes");
        }

        static void ClientReciever_SkinDataChunk(uint clientId, ref NetDataReader reader)
        {
            uint senderClientId = reader.GetUInt();
            string skinName = reader.GetString();
            int chunkIndex = reader.GetInt();
            byte[] chunkData = reader.GetBytesWithLength();

            if (IsLocalPlayer(senderClientId)) return;

            string key = $"{senderClientId}_{skinName}";
            if (!pendingTransfers.TryGetValue(key, out var transfer))
                return;

            if (Time.unscaledTime - transfer.startTime > TRANSFER_TIMEOUT)
            {
                pendingTransfers.Remove(key);
                return;
            }

            int offset = chunkIndex * CHUNK_SIZE;
            if (offset + chunkData.Length <= transfer.data.Length)
            {
                Array.Copy(chunkData, 0, transfer.data, offset, chunkData.Length);
            }
            transfer.receivedChunks++;

            if (transfer.receivedChunks >= transfer.totalChunks)
            {
                GameObject playerObj = FindPlayerByClientId(senderClientId);
                if (playerObj != null)
                {
                    SkinApplier.ApplySkinFromMemory(playerObj, transfer.data);
                    LogInfo($"P2P transfer complete: {skinName} from {senderClientId}");
                }
                else
                {
                    LogInfo($"P2P transfer complete, caching for sender={senderClientId}");
                    completedSkins[senderClientId] = new CompletedSkin
                    {
                        skinName = skinName,
                        data = transfer.data,
                        completeTime = Time.unscaledTime,
                    };
                }
                pendingTransfers.Remove(key);
            }
        }

        static void ClientReciever_SkinStateRelay(uint clientId, ref NetDataReader reader)
        {
            uint senderId = reader.GetUInt();
            bool state = reader.GetBool();
            if (IsLocalPlayer(senderId)) return;
        }

        static void ClientReciever_SkinResendRequest(uint clientId, ref NetDataReader reader)
        {
            uint targetClientId = reader.GetUInt();
            string currentSkin = SkinSync.Instance.currentSkinID;
            if (currentSkin == null) return;

            LogInfo($"SkinResendRequest: resending skin '{currentSkin}' for new client {targetClientId}");
            SendLocalSkinData(currentSkin);
        }

        static bool IsLocalPlayer(uint clientId)
        {
            if (SkinSync.Instance.localNetBody?.player != null)
                return clientId == SkinSync.Instance.localNetBody.player.clientId;
            return false;
        }

        static GameObject FindPlayerByClientId(uint clientId)
        {
            if (playerBodies.TryGetValue(clientId, out var nb) && nb.chara != null)
                return nb.chara;

            if (NetBody.all_instances != null)
            {
                foreach (var inst in NetBody.all_instances)
                {
                    if (inst.player != null && inst.player.clientId == clientId && inst.chara != null)
                    {
                        playerBodies[clientId] = inst;
                        return inst.chara;
                    }
                }
            }
            return null;
        }
    }
}
