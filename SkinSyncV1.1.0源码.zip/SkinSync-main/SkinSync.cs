using BepInEx;
using HarmonyLib;
using KrokoshaCasualtiesMP;
using LiteNetLib;
using LiteNetLib.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SkinSyncMod
{
    [BepInPlugin("com.Bytechey.skinsync", "Skin Sync Mod", "1.1.0")]
    public class SkinSync : BaseUnityPlugin
    {
        internal static Harmony harmony;
        internal static SkinSync Instance;

        internal static string SkinsRoot => Path.Combine(Paths.PluginPath, "SkinSync", "CustomSprites");
        internal static string ConfigFilePath => Path.Combine(Paths.PluginPath, "SkinSync", "skinsync.cfg");

        internal List<string> availableSkins = new List<string>();
        internal int currentSkinIndex = -1;
        internal string currentSkinID = null;

        internal GameObject localPlayerObject;
        internal NetBody localNetBody;

        internal void Awake()
        {
            Instance = this;
            harmony = new Harmony("com.Bytechey.skinsync");
            harmony.PatchAll();
            SkinNetwork.RegisterRecievers();
            SkinApplier.LoadOgSprites();
            SkinUI.Init();
            ScanAvailableSkins();
            LoadConfig();
            SceneManager.sceneUnloaded += OnSceneUnloaded;
            SceneManager.sceneLoaded += OnSceneLoaded;
            Logger.LogInfo($"SkinSync Mod loaded. Found {availableSkins.Count} skins.");
        }

        private void OnSceneUnloaded(Scene scene)
        {
            localNetBody = null;
            localPlayerObject = null;
            SkinApplier.ClearCache();
            SkinUI.ClearPreviewCache();
            SkinNetwork.ClearAllData();
            Logger.LogInfo("[SkinSync] Scene unloaded, cleared player references and skin cache.");
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            if (scene.name != "SampleScene") return;

            if (KrokoshaScavMultiplayer.network_system_is_running)
            {
                SkinNetwork.RegisterRecievers();
            }
            else
            {
                if (currentSkinID != null && TryGetLocalPlayer())
                {
                    SwitchToSkin(currentSkinID);
                }
            }

            Logger.LogInfo($"[SkinSync] Scene loaded: {scene.name}");
        }

        internal void ScanAvailableSkins()
        {
            availableSkins.Clear();
            string customSpritesPath = SkinsRoot;
            if (!Directory.Exists(customSpritesPath))
            {
                Logger.LogWarning($"CustomSprites folder not found at {customSpritesPath}");
                return;
            }

            // [TEMP-LEGACY] st+数字 排序逻辑，保留兼容旧皮肤包
            // 新设计支持任意文件夹名，st+数字 的仍按数字排序放前面
            Regex stPattern = new Regex(@"^st(\d+)$", RegexOptions.IgnoreCase);

            var stSkins = new List<KeyValuePair<int, string>>();
            var otherSkins = new List<string>();

            foreach (var dir in Directory.GetDirectories(customSpritesPath))
            {
                string name = Path.GetFileName(dir);
                var match = stPattern.Match(name);
                if (match.Success)
                {
                    stSkins.Add(new KeyValuePair<int, string>(int.Parse(match.Groups[1].Value), name));
                }
                else
                {
                    otherSkins.Add(name);
                }
            }

            // st+数字 按数字排序在前，其他按字母排序在后
            foreach (var kvp in stSkins.OrderBy(x => x.Key))
                availableSkins.Add(kvp.Value);
            foreach (var name in otherSkins.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
                availableSkins.Add(name);

            if (availableSkins.Count == 0)
                Logger.LogWarning("No skin folders found in CustomSprites.");
            else
                Logger.LogInfo($"Available skins: {string.Join(", ", availableSkins)}");
        }

        internal void LateUpdate()
        {
            SkinApplier.UpdateAllActiveSkins();
            SkinNetwork.CleanupTimedOutTransfers();

            if (currentSkinID != null && localNetBody == null && localPlayerObject == null)
            {
                var activeScene = SceneManager.GetActiveScene();
                if (activeScene.name == "SampleScene")
                {
                    if (TryGetLocalPlayer())
                    {
                        SwitchToSkin(currentSkinID);
                    }
                }
            }
        }

        internal void OnGUI()
        {
            try
            {
                SkinUI.DrawSkinSelector();
            }
            catch (Exception ex)
            {
                Logger.LogWarning($"[SkinSync] UI draw error: {ex.Message}");
            }
        }

        private bool TryGetLocalPlayer()
        {
            if (localNetBody == null && NetBody.all_instances != null)
            {
                foreach (var nb in NetBody.all_instances)
                {
                    if (nb.is_local)
                    {
                        localNetBody = nb;
                        Logger.LogInfo($"Multiplayer mode: found local NetBody (netId {localNetBody.netId})");
                        break;
                    }
                }
                if (localNetBody == null && NetPlayer.LOCAL_PLAYER != null && NetPlayer.LOCAL_PLAYER.body != null)
                {
                    try
                    {
                        var pb = NetPlayer.LOCAL_PLAYER.playerbody;
                        if (pb != null)
                        {
                            localNetBody = pb;
                            Logger.LogInfo("Multiplayer mode: found local NetBody via NetPlayer.LOCAL_PLAYER");
                        }
                    }
                    catch (Exception)
                    {
                        // playerbody getter may throw if body GameObject was destroyed
                    }
                }
            }

            if (localNetBody != null)
                return true;

            if (localPlayerObject == null)
            {
                Body playerBody = FindObjectOfType<Body>();
                if (playerBody != null)
                {
                    localPlayerObject = playerBody.transform.parent?.gameObject ?? playerBody.gameObject;
                    Logger.LogInfo($"Singleplayer mode: found local player object via Body: {localPlayerObject.name}");
                }
                else
                {
                    localPlayerObject = GameObject.FindGameObjectWithTag("Player");
                    if (localPlayerObject != null)
                        Logger.LogInfo($"Singleplayer mode: found local player object via Tag: {localPlayerObject.name}");
                }
            }

            return localPlayerObject != null;
        }

        internal void SwitchToSkin(string skinID)
        {
            currentSkinID = skinID;
            currentSkinIndex = availableSkins.IndexOf(skinID);
            SaveConfig();

            TryGetLocalPlayer();

            if (localNetBody != null)
            {
                SkinApplier.ApplySkinToPlayer(localNetBody.chara, skinID);

                SkinNetwork.SendSkinChange(skinID, localNetBody.netId);
                SkinNetwork.SendLocalSkinData(skinID);

                Logger.LogInfo($"Multiplayer: switched to {skinID}, sent skinID + P2P data.");
            }
            else if (localPlayerObject != null)
            {
                SkinApplier.ApplySkinToPlayer(localPlayerObject, skinID);
                Logger.LogInfo($"Singleplayer: switched to {skinID} (local only).");
            }
            else
            {
                Logger.LogWarning($"Cannot switch to {skinID}: no valid player object.");
            }
        }

        internal void ResetToDefault()
        {
            TryGetLocalPlayer();

            if (localNetBody != null)
            {
                SkinApplier.ResetToDefault(localNetBody.chara);
                SkinNetwork.SendSkinChange(null, localNetBody.netId);
            }
            else if (localPlayerObject != null)
            {
                SkinApplier.ResetToDefault(localPlayerObject);
            }

            currentSkinID = null;
            currentSkinIndex = -1;
            SaveConfig();
            Logger.LogInfo("Reset to default skin.");
        }

        internal void SaveConfig()
        {
            try
            {
                string dir = Path.GetDirectoryName(ConfigFilePath);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                string content = string.IsNullOrEmpty(currentSkinID) ? "" : currentSkinID;
                File.WriteAllText(ConfigFilePath, content);
            }
            catch (Exception ex)
            {
                Logger.LogWarning($"Failed to save config: {ex.Message}");
            }
        }

        internal void LoadConfig()
        {
            try
            {
                if (!File.Exists(ConfigFilePath)) return;

                string skinID = File.ReadAllText(ConfigFilePath).Trim();
                if (string.IsNullOrEmpty(skinID)) return;

                if (availableSkins.Contains(skinID))
                {
                    currentSkinID = skinID;
                    currentSkinIndex = availableSkins.IndexOf(skinID);
                    Logger.LogInfo($"Loaded saved skin from config: {skinID}");
                }
                else
                {
                    Logger.LogWarning($"Saved skin '{skinID}' not found in available skins, skipping.");
                }
            }
            catch (Exception ex)
            {
                Logger.LogWarning($"Failed to load config: {ex.Message}");
            }
        }
    }
}
