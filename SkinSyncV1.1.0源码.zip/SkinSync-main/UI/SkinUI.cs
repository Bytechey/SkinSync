using System;
using System.Collections.Generic;
using System.IO;
using KrokoshaCasualtiesMP;
using KrokoshaCasualtiesUtils;
using UnityEngine;

namespace SkinSyncMod
{
    public static class SkinUI
    {
        private static int _currentPage;
        private static Dictionary<string, Sprite> _previewCache = new Dictionary<string, Sprite>();
        private static Sprite _defaultPreview;
        private static readonly int SkinsPerPage = 4;
        private static bool _styleInitialized;

        private static GUIStyle _skinNameStyle;
        private static GUIStyle _selectedNameStyle;
        private static GUIStyle _pageLabelStyle;

        internal static void Init()
        {
            LoadDefaultPreview();
        }

        private static void LoadDefaultPreview()
        {
            if (_defaultPreview != null) return;
            if (SkinApplier.OgSprites != null && SkinApplier.OgSprites.TryGetValue("experimentHead", out var ogHead))
            {
                _defaultPreview = ogHead;
            }
        }

        internal static Sprite GetPreviewSprite(string skinID)
        {
            if (_previewCache.TryGetValue(skinID, out var cached))
                return cached;

            string headPath = Path.Combine(SkinSync.SkinsRoot, skinID, "Body", "experimentHead.png");
            if (File.Exists(headPath))
            {
                try
                {
                    byte[] data = File.ReadAllBytes(headPath);
                    Texture2D tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                    tex.filterMode = FilterMode.Point;
                    if (ImageConversion.LoadImage(tex, data))
                    {
                        Sprite sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 8f);
                        _previewCache[skinID] = sprite;
                        return sprite;
                    }
                }
                catch (Exception) { }
            }

            _previewCache[skinID] = null;
            return null;
        }

        internal static void ClearPreviewCache()
        {
            _previewCache.Clear();
            _defaultPreview = null;
            _currentPage = 0;
        }

        internal static void DrawSkinSelector()
        {
            if (!IsPauseMenuOpen()) return;

            var skins = SkinSync.Instance?.availableSkins;
            if (skins == null || skins.Count == 0) return;

            LoadDefaultPreview();
            InitStyles();

            float uiScale = UIBullshit.uiScale;
            float slotSize = 80f * uiScale;
            float slotPadding = 12f * uiScale;
            float nameHeight = 24f * uiScale;
            float windowPadding = 16f * uiScale;
            float navButtonWidth = 36f * uiScale;
            float navButtonHeight = 30f * uiScale;

            int totalPages = (skins.Count + SkinsPerPage - 1) / SkinsPerPage;
            if (_currentPage >= totalPages) _currentPage = totalPages - 1;
            if (_currentPage < 0) _currentPage = 0;

            int slotsOnPage = Mathf.Min(SkinsPerPage, skins.Count - _currentPage * SkinsPerPage);
            float contentWidth = slotsOnPage * slotSize + (slotsOnPage - 1) * slotPadding;
            float totalWidth = contentWidth + windowPadding * 2f;
            float totalHeight = slotSize + nameHeight + windowPadding * 2f + 8f * uiScale;

            bool needNav = skins.Count > SkinsPerPage;
            if (needNav)
            {
                totalHeight += navButtonHeight + 8f * uiScale;
            }

            float brightnessBottom = GetBrightnessPanelBottom();
            float gap = 16f * uiScale;
            float windowX = (Screen.width - totalWidth) * 0.5f;
            float windowY = brightnessBottom + gap;

            Rect windowRect = new Rect(windowX, windowY, totalWidth, totalHeight);

            DrawWindowBackground(windowRect);

            float contentX = windowX + windowPadding;
            float contentY = windowY + windowPadding;

            string currentSkin = SkinSync.Instance.currentSkinID;

            for (int i = 0; i < slotsOnPage; i++)
            {
                int skinIndex = _currentPage * SkinsPerPage + i;
                if (skinIndex >= skins.Count) break;

                string skinID = skins[skinIndex];
                float slotX = contentX + i * (slotSize + slotPadding);
                Rect slotRect = new Rect(slotX, contentY, slotSize, slotSize);

                bool isSelected = skinID == currentSkin;

                if (isSelected)
                {
                    Color prevColor = GUI.color;
                    GUI.color = new Color(0.4f, 0.8f, 1f, 0.3f);
                    GUI.DrawTexture(slotRect, Texture2D.whiteTexture);
                    GUI.color = prevColor;
                }

                DrawSlotBorder(slotRect, isSelected);

                Sprite preview = GetPreviewSprite(skinID);
                if (preview != null && preview.texture != null)
                {
                    DrawSpriteInRect(slotRect, preview);
                }
                else if (_defaultPreview != null && _defaultPreview.texture != null)
                {
                    DrawSpriteInRect(slotRect, _defaultPreview);
                }

                if (GUI.Button(slotRect, GUIContent.none, GUIStyle.none))
                {
                    SkinSync.Instance.SwitchToSkin(skinID);
                }

                Rect nameRect = new Rect(slotX, contentY + slotSize + 2f * uiScale, slotSize, nameHeight);
                GUIStyle nameStyle = isSelected ? _selectedNameStyle : _skinNameStyle;
                GUI.Label(nameRect, skinID, nameStyle);
            }

            if (needNav)
            {
                float navY = contentY + slotSize + nameHeight + 6f * uiScale;
                float navCenterX = windowX + totalWidth * 0.5f;

                bool hasPrev = _currentPage > 0;
                bool hasNext = _currentPage < totalPages - 1;

                float navGap = 8f * uiScale;
                float pageLabelWidth = 50f * uiScale;
                float prevBtnX = navCenterX - pageLabelWidth * 0.5f - navGap - navButtonWidth;
                float nextBtnX = navCenterX + pageLabelWidth * 0.5f + navGap;

                GUI.enabled = hasPrev;
                if (GUI.Button(new Rect(prevBtnX, navY, navButtonWidth, navButtonHeight), "<"))
                {
                    _currentPage--;
                }

                GUI.enabled = hasNext;
                if (GUI.Button(new Rect(nextBtnX, navY, navButtonWidth, navButtonHeight), ">"))
                {
                    _currentPage++;
                }

                GUI.enabled = true;

                string pageText = $"{_currentPage + 1}/{totalPages}";
                Rect pageRect = new Rect(navCenterX - pageLabelWidth * 0.5f, navY, pageLabelWidth, navButtonHeight);
                GUI.Label(pageRect, pageText, _pageLabelStyle);
            }
        }

        private static bool IsPauseMenuOpen()
        {
            if (!KrokoshaScavMultiplayer.network_system_is_running)
            {
                return Util.IsInWorld() && PlayerCamera.main != null && PlayerCamera.main.brightnessPanel != null && PlayerCamera.main.brightnessPanel.activeSelf;
            }
            return KrokoshaScavMultiplayer.IsInPauseMenuOrMainMenu() && Util.IsInWorld();
        }

        private static float GetBrightnessPanelBottom()
        {
            if (PlayerCamera.main != null && PlayerCamera.main.brightnessPanel != null)
            {
                var rectTransform = PlayerCamera.main.brightnessPanel.GetComponent<RectTransform>();
                if (rectTransform != null)
                {
                    Vector3[] corners = new Vector3[4];
                    rectTransform.GetWorldCorners(corners);
                    float bottomWorld = corners[0].y;
                    float bottomScreen = Screen.height - bottomWorld * PlayerCamera.main.mainCanvas.transform.localScale.y;
                    return bottomScreen;
                }
            }
            return Screen.height * 0.5f;
        }

        private static void DrawWindowBackground(Rect rect)
        {
            Color prevColor = GUI.color;
            GUI.color = new Color(0.1f, 0.1f, 0.15f, 0.85f);
            GUI.DrawTexture(rect, Texture2D.whiteTexture);
            GUI.color = new Color(0.3f, 0.3f, 0.4f, 0.9f);
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width, 2f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x, rect.y + rect.height - 2f, rect.width, 2f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x, rect.y, 2f, rect.height), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x + rect.width - 2f, rect.y, 2f, rect.height), Texture2D.whiteTexture);
            GUI.color = prevColor;
        }

        private static void DrawSlotBorder(Rect rect, bool selected)
        {
            Color prevColor = GUI.color;
            GUI.color = selected ? new Color(0.4f, 0.8f, 1f, 0.9f) : new Color(0.5f, 0.5f, 0.6f, 0.6f);
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width, 1f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x, rect.y + rect.height - 1f, rect.width, 1f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x, rect.y, 1f, rect.height), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(rect.x + rect.width - 1f, rect.y, 1f, rect.height), Texture2D.whiteTexture);
            GUI.color = prevColor;
        }

        private static void DrawSpriteInRect(Rect rect, Sprite sprite)
        {
            if (sprite == null || sprite.texture == null) return;

            Rect sr = sprite.textureRect;
            float texW = sprite.texture.width;
            float texH = sprite.texture.height;

            Rect uvRect = new Rect(sr.x / texW, sr.y / texH, sr.width / texW, sr.height / texH);

            float aspect = sr.width / sr.height;
            float drawW, drawH;
            if (aspect > 1f)
            {
                drawW = rect.width * 0.85f;
                drawH = drawW / aspect;
            }
            else
            {
                drawH = rect.height * 0.85f;
                drawW = drawH * aspect;
            }

            float drawX = rect.x + (rect.width - drawW) * 0.5f;
            float drawY = rect.y + (rect.height - drawH) * 0.5f;

            Rect drawRect = new Rect(drawX, drawY, drawW, drawH);

            Color prevColor = GUI.color;
            GUI.color = Color.white;
            GUI.DrawTextureWithTexCoords(drawRect, sprite.texture, uvRect);
            GUI.color = prevColor;
        }

        private static void InitStyles()
        {
            if (_styleInitialized) return;
            _styleInitialized = true;

            _skinNameStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = Mathf.RoundToInt(11f * UIBullshit.uiScale),
                normal = { textColor = new Color(0.75f, 0.75f, 0.8f) }
            };

            _selectedNameStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = Mathf.RoundToInt(11f * UIBullshit.uiScale),
                fontStyle = FontStyle.Bold,
                normal = { textColor = new Color(0.4f, 0.8f, 1f) }
            };

            _pageLabelStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = Mathf.RoundToInt(10f * UIBullshit.uiScale),
                normal = { textColor = new Color(0.7f, 0.7f, 0.75f) }
            };
        }
    }
}
